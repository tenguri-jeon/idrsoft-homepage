document.addEventListener("DOMContentLoaded", function () {
    new TypeIt("#simpleUsage",  {
        speed: 100,
        waitUntilVisible: true,
      }).go();
  });

